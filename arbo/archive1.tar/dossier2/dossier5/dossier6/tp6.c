#include<stdio.h>
#include<assert.h>
#include<stdlib.h>

    typedef struct node {
        int val;
        struct node *prev;
        struct node *next;
    } node;

    typedef struct {
        node *first;
        node *last;
    } dl_list;

    typedef dl_list* list;

    //EXERCICE 1

    void print_dl(dl_list* list){
        assert(list -> first != NULL && list -> last != NULL);
        node* current = list -> first;
        do{
            printf("%d ",current -> val);
            current = current -> next;
        } while(current != list -> last);
        printf("\n");
    }

    void print_dl_rev(dl_list* list){
        assert(list -> first != NULL && list -> last != NULL);
        node* current = list -> last;
        do{
            printf("%d ",current -> val);
            current = current -> prev;
        } while(current != list -> first);
        printf("\n");
    }

    //EXERCICE 2

    dl_list* dl_alloc(){
        dl_list* list = malloc(sizeof(list));
        assert(list != NULL);
        return list;
    }

    void dl_free(dl_list *list){
        assert(list -> first != NULL && list -> last != NULL);
        node* current = list-> first;
        while(current != NULL){
            node* suivant = current->next;
            free(current);
            current = suivant;
        }
        list->first = NULL;
        list->last = NULL;
        free(list);
    }

    node* elmt_alloc(int val){
         node* new_node = malloc(sizeof(node));
         assert(new_node != NULL);
         new_node -> val = val;
         new_node -> prev = NULL;
         new_node -> next = NULL;
         return new_node;
     }

    void elmt_free(node* elmt){
          assert(elmt != NULL);
          free(elmt);
    }

    //EXERCICE 3

    void link_nodes(dl_list* list, node* elmt_l, node* elmt_r){
        if(elmt_l != NULL){
            elmt_l -> next = elmt_r;
        } else {
            list -> first = elmt_r;
        }

        if(elmt_r != NULL){
            elmt_r -> prev = elmt_l;
        } else {
            list -> last = elmt_l;
        }
    }

    //EXERCICE 4

    int main(void){
        return 1;
    }
