#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

    int* creation(size_t capacite){
        int *tab = malloc(capacite);
        if(tab != NULL){
            return NULL;
        }
        return tab;
    }

    void supprimer(int *tab){
        free(tab);
    }

    int* ajouter(int* tab, size_t* taille, size_t* capacite, size_t pos, int val){
        assert(pos <= *taille);
        if(*taille < *capacite)
            tab = realloc(tab,(*capacite*2)*sizeof(int));

        if(tab[pos] == val){
            tab[*taille+1] = val;
            //*taille = taille +1;
        } else {

        }
        return tab;
    }

    void effacer(int* tab, size_t* taille, size_t pos){
        assert(pos <= *taille);
        for(int i = *pos; i < *taille; i++){
            tab[i] = tab[i+1];
        }
        *taille++;
    }

    void modifier(int* tab, size_t taille, size_t pos, int val){
        assert(pos <= taille);
        tab[pos] = val;
    }

    int obtenir(int* tab, size_t taille, size_t pos){
        assert(pos <= taille);
        return tab[pos];
    }

    int main(void){
        //int* tab = creation(0);
        return 0;
    }
