
public class TableRonde {
	private CellRob courant;

	public TableRonde(Robot rob) {
		this.courant = new CellRob(rob,null,null);
		this.courant.setPrecedent(this.courant);
		this.courant.setSuivant(this.courant);
		
	}
	
	public void affiche() {
		CellRob first = this.courant;
		do {
			first.getRob().description();
			first = first.getSuivant();
		} while(first != this.courant);
	}
	
	public void ajouteRob(Robot r) {
		CellRob c = new CellRob(r,this.courant,this.courant.getPrecedent());
		this.courant.getPrecedent().setSuivant(c);
		this.courant.setPrecedent(c);
	}
	
	public boolean supprimer_n (int n) {
		if(this.courant == null)
			return false;
		if(this.courant.getRob().getId() == n) {
			this.courant.getPrecedent().setSuivant(this.courant.getSuivant());
			this.courant.getSuivant().setPrecedent(this.courant.getPrecedent());
			this.courant = this.courant.getSuivant();
			return true;
		}
		return this.courant.supprimer_n(n,this.courant);
	}
	
	public boolean supprimer_c(char c) {
		if(this.courant == null)
			return false;
		if(this.courant.getRob().getNom() == c) {
			this.courant.getPrecedent().setSuivant(this.courant.getSuivant());
			this.courant.getSuivant().setPrecedent(this.courant.getPrecedent());
			this.courant = this.courant.getSuivant();
			return true;
		}
		return this.courant.supprimer_c(c,this.courant);
	}
	
	public void tourParole() {
		int compteur = 0;
		int tour = 0;
		CellRob debut = this.courant;
		while(compteur < Robot.getNbTotal()-1) {
			if(debut.getRob().finiDeParler() == true) {
				this.supprimer_c(debut.getRob().getNom());
				compteur++;
			}
			if(tour <= 0) {
				debut.getRob().parle(5);
				debut.getRob().setNP(debut.getRob().getNP()-5);
			} else {
				System.out.print(debut.getRob().getNom()+": ");
				for(int i = 5; i < debut.getRob().getTexteLength(); i++) {
					System.out.print(debut.getRob().getText().charAt(i));
				}
				System.out.println();
				debut.getRob().setNP(0);
			}
			debut = debut.getSuivant();
			if(debut == this.courant) tour++;
		}
	}
	
	public CellRob getCourant(){
		return this.courant;
	}
}
