
public class CellRob {
	private Robot rob;
	private CellRob suivante;
	private CellRob precedente;
	
	public CellRob(Robot rob, CellRob suivante, CellRob precedente) {
		this.rob = rob;
		this.suivante = suivante;
		this.precedente = precedente;
	}
		
	public boolean supprimer_n(int n, CellRob courant) {
		if(this.suivante != courant) {
			if(this.suivante.getRob().getId() == n) {
				this.suivante.precedente.suivante = this.suivante.suivante;
				this.suivante.suivante.precedente = this.suivante.precedente;
				return true;
			}
			return this.suivante.supprimer_n(n,courant);
		}
		return false;
	}
	public boolean supprimer_c(char c, CellRob courant) {
		if(this.suivante != courant) {
			if(this.suivante.getRob().getNom() == c) {
				this.suivante.precedente.suivante = this.suivante.suivante;
				this.suivante.suivante.precedente = this.suivante.precedente;
				return true;
			}
			return this.suivante.supprimer_n(c,courant);
		}
		return false;
	}
	
	public Robot getRob() {
		return this.rob;
	}
	
	public CellRob getSuivant() {
		return this.suivante;
	}
	
	public CellRob getPrecedent() {
		return this.precedente;
	}
	
	public void setSuivant(CellRob c) {
		this.suivante = c;
	}
	
	public void setPrecedent(CellRob c) {
		this.precedente = c;
	}
}
