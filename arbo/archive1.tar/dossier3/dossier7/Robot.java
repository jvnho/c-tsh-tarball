
public class Robot {
	private static int nbRob;
	private int id;
	private int np;
	private char nom;
	private String texte;
	
	public Robot(char nom, String texte) {
		this.nom = nom;
		this.np = texte.length();
		this.texte = texte;
		this.id = Robot.nbRob;
		Robot.nbRob++;
	}
	public boolean finiDeParler() {
		if(this.np <= 0)
			return true;
		return false;
	}
	public int parle(int n) {
		System.out.print(this.nom+": ");
		for(int i = 0 ; i < n ; i++) {
			System.out.print(this.texte.charAt(i));
		}
		System.out.println();
		return this.np-n;
	}
	
	public void description() {
		System.out.println("Bonjour je suis "+this.nom+", je suis le numéro "+this.id);
	}
	
	public int getId() {
		return this.id;
	}
	public char getNom() {
		return this.nom;
	}
	public static int getNbTotal() {
		return Robot.nbRob;
	}
	public void setNP(int n) {
		this.np = n;
	}
	public int getNP() {
		return this.np;
	}
	public int getTexteLength() {
		return this.texte.length();
	}
	public String getText() {
		return this.texte;
	}
}
