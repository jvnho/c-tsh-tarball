
public class Panier {
	public Fruit[] panier;
	
	public Panier() {
		panier = null;
	}
	
	public Panier(Fruit[] f) {
		panier = f;
	}
	public Panier(Fruit f, Panier p1) {
		Fruit[] p2= new Fruit[p1.panier.length+1];
		for(int i =0; i < p1.panier.length; i++) {
			p2[i]=p1.panier[i];
		}
		p2[p2.length-1] = f;
		panier = p2;
	}
	
	public static void afficher(Panier p) {
		for(int i =0; i<p.panier.length;i++) {
			Fruit.afficher(p.panier[i]);
		}
	}
	
	public static Panier hybridePanier(Fruit f, Panier p) {
		Fruit[] f2 = new Fruit[p.panier.length];
		for(int i = 0; i < p.panier.length; i++) {
			f2[i]=Fruit.hybridation(f,p.panier[i]);
		}
		return new Panier(f2);
	}

}
