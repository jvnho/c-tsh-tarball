
public class Fruit {
	public String nom;
	public int poids;
	
	public Fruit(String pNom, int pPoids) {
		nom=pNom;
		poids=pPoids;
	}
	
	public static void afficher(Fruit f) {
		System.out.println("Ce fruit est un(e) "+f.nom+" et pèse "+ f.poids+" grammes.");
	}
	static Fruit hybridation(Fruit f1,Fruit f2) {
		return new Fruit((f1.nom+f2.nom),f1.poids+f2.poids);
	}
}
